import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Homepage from "./components/HomePage/Homepage";
import "../node_modules/font-awesome/css/font-awesome.min.css";

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Homepage />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
