import React from "react";
// import "../Navigation/LeftNav.css";

class LeftNav extends React.Component {
  constructor() {
    super();
    this.state = {
      style: "menu",
      menuStatus: "open",
    };
  }

  componentDidMount() {
    this.setState({ menuStatus: "open", style: "menu active" });
  }

  render() {
    return (
      <div>
        <div
          className={this.state.style}
          style={{
            backgroundColor: "rgb(16, 35, 81)",
            marginLeft: "-6px",
            marginTop: "112px",
            width: "275px",
          }}
        >
          <div
            className="item"
            onClick={this.props.manufacturerclicked}
            style={{
              paddingTop: "20px",
            }}
          >
            <i
              class="fa fa-th-large "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "7%",
              }}
            >
              {" "}
              Dashboard
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-user "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "25%",
              }}
            >
              {" "}
              User
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-envelope "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "28%",
              }}
            >
              {" "}
              Mail
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-bar-chart "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                fontSize: "20px",
                color: "white",
              }}
            ></i>
            <p
              style={{
                color: "white",
                fontSize: "20px",
                paddingLeft: "5%",
                paddingRight: "20%",
                marginTop: "-5px",
              }}
            >
              {" "}
              Reports
            </p>
            {/* <Link to="/login" style={{ color: "white", fontSize: "20px" }}> Workshop</Link> */}
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-file-text-o "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "26%",
              }}
            >
              {" "}
              Data
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-picture-o "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "20%",
              }}
            >
              {" "}
              Images
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-bell "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "3%",
              }}
            >
              {" "}
              Notifications
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-tasks "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "27%",
              }}
            >
              {" "}
              Tasks
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>

          <div className="item2">
            <i
              class="fa fa-bug "
              aria-hidden="true"
              style={{
                marginLeft: "15px",
                float: "left",
                color: "white",
                fontSize: "20px",
              }}
            ></i>
            &nbsp; &nbsp;
            <p
              style={{
                color: "white",
                fontSize: "20px",
                marginTop: "-25px",
                paddingLeft: "5%",
                paddingRight: "26%",
              }}
            >
              {" "}
              Bugs
            </p>
            &nbsp; &nbsp;
            <i
              className="fa fa-chevron-down	"
              aria-hidden="true"
              style={{
                float: "right",
                marginRight: "11px",
                marginTop: "-36px",
                color: "white",
              }}
            ></i>
          </div>
        </div>
      </div>
    );
  }
}
export default LeftNav;
