import React, { Component } from "react";
import axios from "axios";
import { MDBTable, MDBTableBody, MDBTableHead } from "mdbreact";
import LeftNav from "../LeftNav/LeftNav";
import ReactPaginate from "react-paginate";
import "../HomePage/Homepage.css";
import Avatar from "../../assets/wishtree.png";

class Homepage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      test: [],
      users: [],
    };
  }

  componentDidMount() {
    this.getApiData();
  }

  getApiData() {
    axios
      .get("http://60570e0c055dbd0017e8461a.mockapi.io/users/users", {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET",
        },
      })
      .then((res) => {
        // if (this._isMounted) {
        const users = res.data;
        // const vehicle_details = viewassets.slice(0, 49);
        // const vehicle_details = viewassets.filter(
        //   (item) => item.vehicle_details
        // );
        console.log("newapi:", users);

        this.setState({ users });

        //}
      });
  }

  handleSearch = (e) => {
    let currentList = [];
    let newList = [];
    let searchString = e.target.value;
    console.log("serachstring:", searchString);
    debugger;
    if (searchString !== null) {
      currentList = [...this.state.viewassets];
      newList = currentList.filter((item) => {
        let lc = "",
          filter = "";
        if (item.WorkShopName !== "") {
          lc = item.WorkShopName.toLowerCase();
          filter = e.target.value.toLowerCase();
        }
        debugger;

        return lc.includes(filter);
      });
    } else {
      newList = [...this.state.viewassets];
    }
    const viewassets = [...newList];
    var slice = viewassets.slice(
      this.state.offset,
      this.state.offset + this.state.perPage
    );

    this.setState({
      viewassets,

      pageCount: Math.ceil(newList.length / this.state.perPage),
      orgtableData: newList,
      tableData: slice,
    });
    if (searchString === "") {
      this.getApiData();
    }
  };

  handleSearch = (e) => {
    let currentList = [];
    let newList = [];
    let searchString = e.target.value;
    console.log("serachstring:", searchString);
    debugger;
    if (searchString !== null) {
      currentList = [...this.state.users];
      newList = currentList.filter((item) => {
        let lc = "",
          filter = "";
        if (item.name !== "") {
          lc = item.name.toLowerCase();
          filter = e.target.value.toLowerCase();
        }
        debugger;

        return lc.includes(filter);
      });
    } else {
      newList = [...this.state.name];
    }
    const users = [...newList];

    this.setState({
      users,
    });
    if (searchString === "") {
      this.getApiData();
    }
  };
  render() {
    const items = this.props.items;
    const viewassets = this.props.viewassets;
    console.log("viewassets:", viewassets);
    const detailitems = this.props.tritem;

    return (
      <div className="homepage" style={{ display: "flex" }}>
        <LeftNav></LeftNav>
        <div
          className="recordsview"
          style={{
            background: "#f9f9fa",
            marginLeft: "2%",
            marginRight: "2%",
            width: "100%",
          }}
        >
          <div className="container" style={{ marginBottom: "10px" }}>
            <nav
              class="navbar navbar-expand-sm "
              style={{ borderBottom: "2px solid #dbdbdc", marginLeft: "-36px" }}
            >
              <a class="navbar-brand" href="#">
                <img
                  src={Avatar}
                  alt="Avatar"
                  style={{
                    marginLeft: "-365px",
                    height: "86px",
                    width: "256px",
                  }}
                />{" "}
              </a>

              <ul class="navbar-nav">
                <li class="nav-item">
                  <h4
                    style={{
                      //   borderBottom: "2px solid #dbdbdc",
                      color: "#102351",
                      fontSize: "40px",
                      width: "100%",
                      height: "30px",
                      background: " rgba(249,249,250,255)",
                    }}
                  >
                    Users Data
                  </h4>{" "}
                </li>
                <li class="nav-item">
                  <div className="icons" style={{ paddingLeft: "730%" }}>
                    <i
                      class="fa fa-user-circle "
                      style={{
                        fontSize: "25px",
                        marginRight: "85px",
                        color: "#102351",
                        marginTop: "20px",
                      }}
                    ></i>
                    {/*{" "} */}
                  </div>
                  <i
                    className="fa fa-chevron-down	"
                    style={{
                      float: "right",
                      fontSize: "15px",
                      marginRight: "-750px",
                      color: "#102351",
                      marginTop: "-18px",
                    }}
                    aria-hidden="true"
                  ></i>
                </li>
              </ul>
            </nav>
          </div>

          <div className="topnav">
            <button
              type="button"
              id="transfer"
              class="btn"
              style={{
                marginLeft: "15px",
                background: "rgb(16, 35, 81)",
                color: "rgb(255, 255, 255)",
                width: "10%",
                paddingTop: "0.5%",
                paddingBottom: "0.5%",
                float: "left",
              }}
              onClick={() => this.setShow(item, true)}
            >
              <i class="fa fa-plus" aria-hidden="true"></i> &nbsp; Add User
            </button>
            <div
              className="search-container"
              style={{ float: "right", marginRight: "45px" }}
            >
              <form>
                <input
                  type="search"
                  placeholder="Search.."
                  name="search"
                  onChange={this.handleSearch}
                  style={{
                    border: "2px solid rgb(219, 219, 220)",
                    paddingBottom: "3.5%",
                    paddingTop: "3.5%",
                  }}
                />
                <button
                  type="submit"
                  style={{
                    background: "rgb(16, 35, 81)",
                    paddingBottom: "3.5%",
                    paddingTop: "3.5%",
                  }}
                  onClick={this.handleSearch}
                >
                  <i className="fa fa-search" style={{ color: "white" }}></i>
                </button>
              </form>
            </div>
          </div>

          <div
            className="recordsview"
            style={{
              marginTop: "11px",
              background: "#ffffff",
              width: "100%",
              float: "right",
            }}
          >
            {/* <fieldset style={{border:"2px solid aqua" , borderRadius:"6px", borderColor:"aqua", backgroundColor:"rgba(0, 0, 0, 0.9)", width:"79%", marginLeft:"173px"}}> */}
            {/* <legend style={{marginLeft:"-409px", color:"aqua", fontSize:"24px", width:"13%"}}>Records View</legend> pagination={paginationFactory(options)}*/}

            <MDBTable class="ViewTable" style={{ width: "100%" }}>
              <MDBTableHead>
                <tr style={{ color: "rgb(16, 35, 81)" }}>
                  <th
                    colspan="1"
                    onClick={() => this.props.onSort("ManufacturerName")}
                  >
                    ID
                  </th>
                  <th
                    colspan="1"
                    onClick={() => this.props.onSort("EngineCapacity")}
                  >
                    Name
                  </th>
                  <th colspan="1" onClick={() => this.props.onSort("colour")}>
                    Email Address
                  </th>
                  <th
                    colspan="1"
                    onClick={() => this.props.onSort("ownerShip")}
                  >
                    Role
                  </th>

                  <th colspan="1" onClick={() => this.props.onSort("mileage")}>
                    Language{" "}
                  </th>
                  {/* <th onClick={() => this.props.onSort("mileage")}>
                    Service Date
                  </th> */}
                  <th colspan="1">Edit</th>
                  <th colspan="1">Remove</th>
                </tr>
              </MDBTableHead>
              <MDBTableBody>
                {this.state.users.map((item) => {
                  return (
                    <tr class="TableRow" style={{ color: "#5e6b89" }}>
                      <td
                        rowSpan="1"
                        style={{ paddingTop: "5px", paddingBottom: "5px" }}
                      >
                        {item.id}
                      </td>
                      <td
                        rowSpan="1"
                        style={{ paddingTop: "5px", paddingBottom: "5px" }}
                      >
                        {item.name}
                      </td>

                      <td
                        rowSpan="1"
                        style={{ paddingTop: "5px", paddingBottom: "5px" }}
                      >
                        {item.email}
                      </td>

                      <td
                        rowSpan="1"
                        style={{ paddingTop: "5px", paddingBottom: "5px" }}
                      >
                        {item.role}
                      </td>

                      <td
                        rowSpan="1"
                        style={{ paddingTop: "5px", paddingBottom: "5px" }}
                      >
                        {item.language}
                      </td>

                      <td
                        rowSpan="1"
                        style={{ paddingTop: "5px", paddingBottom: "5px" }}
                      >
                        <i
                          class="fa fa-pencil"
                          aria-hidden="true"
                          style={{
                            color: "rgb(16, 35, 81)",
                            paddingTop: "5px",
                            paddingBottom: "5px",
                          }}
                        ></i>
                      </td>
                      {/* <hr></hr> */}
                      <td rowSpan="1">
                        <i
                          class="fa fa-trash"
                          style={{
                            color: "rgb(16, 35, 81)",
                            paddingTop: "5px",
                            paddingBottom: "5px",
                          }}
                          aria-hidden="true"
                        ></i>
                      </td>
                    </tr>
                  );
                })}
              </MDBTableBody>
            </MDBTable>
          </div>

          <ReactPaginate
            previousLabel={"prev"}
            nextLabel={"next"}
            breakLabel={"..."}
            breakClassName={"break-me"}
            marginPagesDisplayed={2}
            pageRangeDisplayed={5}
            onPageChange={this.handlePageClick}
            containerClassName={"pagination"}
            subContainerClassName={"pages pagination"}
            activeClassName={"active"}
          />
        </div>
      </div>
    );
  }
}
export default Homepage;
